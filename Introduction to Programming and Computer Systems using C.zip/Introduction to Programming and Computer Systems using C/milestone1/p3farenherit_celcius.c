#include<stdio.h>
int main()
{
float farenheit, celcius;
printf("enter temperature in farenheit:");
scanf("%f",&farenheit);
celcius=(farenheit-32)*5/9;
printf("%f F = %f C ",farenheit,celcius);
return 0;
}