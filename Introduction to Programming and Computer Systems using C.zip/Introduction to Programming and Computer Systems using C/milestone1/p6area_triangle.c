#include<stdio.h>
int main()
{
float height,base,area;
printf("enter height of triangle");
scanf("%f",&height);
printf("enter base of triangle");
scanf("%f",&base);
area=(base*height)/2;
printf("area of triangle is : %f",area);
return 0;
}