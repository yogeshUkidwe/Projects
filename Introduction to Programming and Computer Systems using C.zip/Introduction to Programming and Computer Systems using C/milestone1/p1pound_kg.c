#include<stdio.h>
float pounds=99 ,kg;
int main1()
{
	
	printf("enter weight in pounds:");
	scanf("%f",&pounds);
	kg=pounds*0.453592;
	printf("%flb = %fkg ",pounds,kg);
	return 0;
}