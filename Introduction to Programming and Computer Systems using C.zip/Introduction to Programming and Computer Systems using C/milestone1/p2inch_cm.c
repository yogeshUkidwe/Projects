#include<stdio.h>
int main()
{
float inches,centimeters;
printf("enter length in inches:");
scanf("%f",&inches);
centimeters=inches*2.54;
printf("%finch = %fcm ",inches,centimeters);
return 0;
}