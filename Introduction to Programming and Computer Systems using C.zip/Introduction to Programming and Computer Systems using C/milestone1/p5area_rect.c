#include<stdio.h>
int main()
{
float length,width,area;
printf("enter lengh of rectangle");
scanf("%f",&length);
printf("enter width of rectangle");
scanf("%f",&width);
area=length*width;
printf("area of rectangle is : %f",area);
return 0;
}