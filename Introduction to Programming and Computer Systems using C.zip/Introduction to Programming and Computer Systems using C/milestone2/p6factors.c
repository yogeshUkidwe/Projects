#include <stdio.h>
int factors(int num);
int main()
{
	int num;
	printf("enter the number");
	scanf("%d",&num);
	
	printf("fctors are :\n");
	factors(num);
	
	return 0;
	
}
int factors(int num)
{
	
	
	for( int i=1;i<=num;i++)
	{
		if(num%i==0)
		{
			printf("%d \n",i);
        }
	}
	return 0;
}
