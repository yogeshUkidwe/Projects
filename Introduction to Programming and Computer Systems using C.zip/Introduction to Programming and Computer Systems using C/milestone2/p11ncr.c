#include<stdio.h>
int fact(int x);
int main()
{
	int n,r,nr,ans;
	printf("enter value of n ");
	scanf("%d",&n);
	printf("enter value of r ");
	scanf("%d",&r);
	nr=n-r;
	ans=fact(n)/(fact(r)*fact(nr));
	printf("ncr is %d",ans);
}
int fact(int x)
{
int factorial = 1;
    if (x == 0)
    {
        return(factorial);
    }
    else
	{
		for(int i=1;i<=x;++i)
		{
			factorial*=i;
		}
	}
	return(factorial);
	return 0;
}