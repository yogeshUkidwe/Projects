#include<stdio.h>
#include <math.h>
double FV(double rate, unsigned int nperiods, double PV) ;
int main()
{
	double PV,rate;
	unsigned int nperiods;
	printf("enter rate for future value");
	scanf("%lf",&rate);
	printf("enter nperiods for future value");
	scanf("%u",&nperiods);
	printf("enter PV for future value");
	scanf("%lf",&PV);
	FV( rate, nperiods, PV);

}

double FV(double rate, unsigned int nperiods, double PV)
{
	double fv,b;
	b=(rate/100)+1;
	fv=PV*pow(b,nperiods);
	printf ("FV IS %lf",fv);
	return 0;
	
}
