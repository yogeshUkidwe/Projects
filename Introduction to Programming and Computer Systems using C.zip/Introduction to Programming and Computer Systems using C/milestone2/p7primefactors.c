#include <stdio.h>
int prime_factors(int num);
int main()
{
	int num1;
	printf("enter the number ");
	scanf("%d",&num1);
	
	printf("prime fctors are :\n");
	prime_factors(num1);
	
	return 0;
	
}
int prime_factors(int num1)
{
	int flag;
	for (int i=2;i<=num1;i++)
	{
		if(num1%i==0)
		{
			flag=1;
			for( int j=2;j<=i/2;j++)
			{
				if(i%j==0)
				{
					flag=0;
					break;
			
				}
			}
		if(flag==1)
            {
                printf("%d \n", i);
            }
		}
		
	}	
		
	return 0;	
}
	
