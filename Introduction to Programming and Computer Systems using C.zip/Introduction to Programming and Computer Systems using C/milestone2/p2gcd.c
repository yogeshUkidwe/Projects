#include<stdio.h>
#include <math.h>
int gcd(int x,int y);
int result;
int main()
{
	int x, y;
	printf("enter the x ");
	scanf("%d",&x);
	printf("eneter y ");
	scanf("%d",&y);
	result=gcd(x, y);
	printf("result is %d",result);
	return 0;
}
int gcd(int x,int y)
{
	
    for( int i=1; i <= x && i <= y; ++i)
    {
	
        if(x%i==0 && y%i==0)
		{
          result =i;
		 
		} 
		
    }
	return result;
}