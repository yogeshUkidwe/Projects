#include<stdio.h>
#include<math.h>

double PV(double rate, unsigned int nperiods, double FV) ;
int main()
{
	double rate,FV;
	unsigned int nperiods;
	printf("enter rate for present value");
	scanf("%lf",&rate);
	printf("enter nperiods for present value");
	scanf("%u",&nperiods);
	printf("enter  future value");
	scanf("%lf",&FV);
	PV( rate, nperiods, FV);
	return 0;
}

double PV(double rate, unsigned int nperiods, double FV)
{
	double pv,a;
	a=(rate/100)+1;
	 pv=FV/pow(a,nperiods);
	//PV1 = FV / ((a*pow(rate,nperiods));
	printf ("PV IS %lf",pv);
	return 0.00;
}