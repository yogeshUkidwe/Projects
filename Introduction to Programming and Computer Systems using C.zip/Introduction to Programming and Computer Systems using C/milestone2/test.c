#include <stdio.h>
int square(int m, int n);
int FV(double rate, unsigned int nperiods, double PV);
int main()
{ 
int m=0,n=0,ans=0;
	printf( "enter two number");
	scanf("%d",&m);
	scanf("%d",&n);
	scanf("%d",&o);
	//ans=  square(m,n);
	//ans=gcd(m,n);
	//ans=prime(m);
	//ans=FV(2,2,110);
	ans=lcm(m,n,o);
	printf("  %d  ",ans);
  	return 0;
}
int square(int m, int n)
{
	int sum =1;
	for(int i=0;i<n;i++)
	sum*=m;
	return sum;
}
int gcd(int m, int n)
{
	int temp=0,i;
	for(i=1;i<=m || i<=n;i++)
	{
		if(m%i==0 && n%i==0)
			temp=i;
	}
	return temp;
}
int prime( int m)
{
	int i,temp=0;
	for(i=2;i<m;i++)
	{
		if(m%i==0)
			break;
		else
			temp=1;
	}
	return temp;
}
int FV(double rate, unsigned int nperiods, double PV)
{
	int ans=PV* square((int)(1+rate),(int)nperiods);
	return ans;
}
int lcm(int x,int y, int z)
{
	int ans=0,i;
	for(i=2;i<=x || i<=y || i<=z;i++)
	{
		if((x%i)==0&& (y%i)==0 && (z%i)==0)
			if(((x/i)*=i)==((y/i)*=i)==((z/i)*=i))
			ans=(x/i);
	}
	return ans;
}


		
		
		
		
		
		
		
		
		