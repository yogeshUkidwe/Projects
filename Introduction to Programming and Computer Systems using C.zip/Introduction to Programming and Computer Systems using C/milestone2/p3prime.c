#include<stdio.h>
int is_prime(unsigned int num);
int main()
{
unsigned int num;
printf("enter the number ");
scanf("%u",&num);
printf("%u",is_prime(num));
return 0;
}
int is_prime(unsigned int num)
{
	for (int i=2;i<num;i++)
	{
		if(num%i==0)
		{
			printf("%u is not prime number\n",num);
			return 0;
		
			break;
		
		}
		else
		{
			printf("%u is prime number\n",num);
			return 1;
			break;
		
		}
		
	}
	return 0;
}