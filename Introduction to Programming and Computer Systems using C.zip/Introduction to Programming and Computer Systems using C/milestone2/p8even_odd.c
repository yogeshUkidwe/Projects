#include <stdio.h>
int even_odd(int num2);
int main()
{
	int num2;
	printf("enter the number");
	scanf("%d",&num2);
	printf("prime fctors are :\n");
	even_odd(num2);
	return 0;
	
}
int even_odd(int num2)
{
	if(num2%2==0)
	{
		printf("%d is even number",num2);
	}
	else 
	{
		printf("%d is odd number",num2);
	}
	return 0;	
}	