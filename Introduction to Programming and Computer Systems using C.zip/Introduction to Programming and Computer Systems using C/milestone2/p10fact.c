#include<stdio.h>
unsigned int fact(unsigned int n);
int main()
{
	unsigned int n ;
	printf("enter the number");
	scanf("%u",&n);
	fact(n);
}
unsigned int fact(unsigned int n)
{
	unsigned long int factorial =1;
	for(int i=1;i<=n;++i)
	{
		factorial*=i;
	}
	printf("factorial is %ld",factorial);
	return 0;
}