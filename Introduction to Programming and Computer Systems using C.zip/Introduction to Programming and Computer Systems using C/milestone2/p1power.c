#include<stdio.h>

double power(double x, int n) ;

int main()
{
	double x;
	int n;
	printf("enter the x ");
	scanf("%lf",&x);
	printf("eneter n ");
	scanf("%d",&n);
	power( x,  n) ;
	
	return 0;
}
double power(double x, int n) 
{
	double result=1;
	 while (n != 0)
    {
        result*= x;
        --n;
    }
	printf("result is %lf",result);
	return 0;
}





