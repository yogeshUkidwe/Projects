#ifndef ownarray
#define ownarray
int sort(int flag,int n,char **arr);
int searchf(char *arr,char *b,int size);
int length(char *str);
int str_remove(char **arr,char *b,int size);
void *mem_copy(void *dest, const void *src, unsigned int n);
int str_compare(char *str1, char *str2);
int str_add(char **str1, char *str2,int size);
int str_sort(char **arr,int size,int flag);
int str_compare1(char *str1, char *str2);
int str_copy1(char str1[], char str2[]);
#endif