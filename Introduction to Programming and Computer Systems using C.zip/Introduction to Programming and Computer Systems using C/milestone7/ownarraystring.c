#include<stdio.h>
#include"ownarraystring.h"
#include<stdlib.h>

int length(char *str)
{ 
	int i;
	for( i = 0; str[i] != '\0'; i++)
	{
		
	}
	return (i);
	return 0;
	
}
 void *mem_copy(void *dest, const void *src, unsigned int n)
{
int i=0;
char *src1=(char *)src;
char *dest1=(char *)dest;
	
  
         for(i=0;i<=n;i++)
      {  
	    dest1[i]=src1[i];
      }
   
   
      
    
	
	return dest1; 
   return 0;
} 

int str_compare(char *str1, char *str2)
{
	int flag=0;
	int len=length(str1);
	int len1=length(str2);

	if(len==len1)
	{
		for( int i = 0; i<len1; i++)
		{
			if(*(str1+i)==*(str2+i))
			{
				
				flag++;
				
			}
			else
			{
				return 1;
				
				}
		
		}
	}
	if(len1==flag)
	{
		
		return 3;
	}
	if(len!=len1)
	{
		return 1;
	}
	return 0;
}
int str_add(char **str1, char *str2,int size)
{
	int  mlag=0;
	
	int found=0;
	for( int i = 0; i<size; i++)
	{
		found=str_compare(*(str1+i),str2);
		if(found==3)
		{
	    
				mlag=i;
				break;
		}	
		
	}
	if(found==3)
	{
		printf("string is found at position %d \n ",mlag+1);
		return mlag;
	}
		
	if(found==1)
	{
		return -1;
	}
	return 0;
}
int str_ascii(char *str)
{
	int temp;
	for(int i=0;i<length(str);i++)
	{
	temp+=str[i];
	}
	return temp;
}
int str_remove(char **arr,char *b,int size)
{
	int remove=str_add(arr,b,size);
	if(remove!=-1)
	{
			for (int i = remove; i <  size ; i++)
			{
				*(arr+i)= *(arr+i+1);
			}
		printf("%s is deleted from %d position \n",b,remove);
		return 1;
	}
	else
	{
		printf("not found");
	}

	return 0;
}
int str_compare1(char *str1, char *str2)
{
	int flag=0,mlag=0,lag=0,n=0;
	int len =length(str1);
	int len1=length(str2);
	if(len>len1)
	{
		return 1;
	}
	else if(len<len1)
	{
		return 2;
	}
	else if (len==len1)
	{
		len =n;
	}
		
	for( int i = 0; i<=n; i++)
	{
		if(str1[i]>str2[i])
		{
			flag++;
		}
		else if(str1[i]<str2[i])
		{
			mlag++;
		}
		else 
		{
			lag++;
		}
	}
	if (lag>flag && lag>mlag)
	{
		return 3;
	}
	else if (flag>mlag)
	{
		return 1;
	}
	else if(flag<mlag)
	{
		return 2;
	}
	else
	{
	if(str1==NULL || str2==NULL )
	{
		printf("-1 error found \n");
	}
	return 9;
	}
	return 0;
}
int str_sort(char **arr,int size,int flag)
{
	

	char *temp=(char*) malloc(100*sizeof(char));
	if(flag==0)
	{
	for(int i=0;i<size; i++)
		{
		
			for(int j=i+1; j<size; j++)
			{
				if(str_compare1(*(arr+i),*(arr+j))==1)
					{
					
					(temp)= *(arr+i);
					*(arr+i) = *(arr+j);
					*(arr+j) =(temp);
					}

			}
		printf("%s \n",*(arr+i));	
		}
	}
	else if(flag==1)
	{
		for(int i=0;i<size; i++)
		{
		
			for(int j=i+1; j<size; j++)
			{
				if(str_compare1(*(arr+i),*(arr+j))==2)
					{
						(temp)= *(arr+i);
						*(arr+i) = *(arr+j);
						*(arr+j) =(temp);
					}

			}
			printf("%s \n",*(arr+i));	
		}
	}
	return 0;
}