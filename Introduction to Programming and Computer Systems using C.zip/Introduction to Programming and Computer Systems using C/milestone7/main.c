#include<stdio.h>
#include<stdlib.h>

#include"ownarraystring.h"
int main()
{
	int choice,size=0,m=2,found=0,flag=0;
	char b[1000];
	char** arr;
	int l=0;
	 arr=(char**)malloc(1*sizeof(char*));
	while(1)
	{
	
	 arr=(char**)realloc(arr,sizeof(char*)*(size+1));
	 
	printf(" 1. Add an element to the Array the application should not allow the user to enter  the same number twice \n 2. Search if an element exists in the array \n 3. Remove an element from the array \n 4. Sort the array  \n 5. Print all elements in the array \n 6. Exit \n");
	printf("enter your choice ");
	scanf("%d",&choice);
	
	switch(choice)
	{
		case 1:
		
			printf("%d\n",size);
			printf("enter string");
			
			scanf(" %[^\n]s",b);
			l=length(b);
			//int searchf(char *arr,char *b,int size);
			m=str_add( arr,b,size );
			if(m==-1||size==0)
			{
				*(arr+size) = (char*)malloc((l+1 )* sizeof(char));
				
				*(arr+size) = (char*)realloc(*(arr+size),(l+1)* sizeof(char));
				mem_copy(*(arr+size),b,l);
				printf("\n length is %d",l);
				size++;
				printf(" inserted \n");
			}
			else 
			{
			printf(" \n not inserted");
			}
			break;
		case 2:
			printf("enter search string");
			scanf("%s",b);
			found=str_add((arr),b,size);
			printf("%d",found);
			
			break;
		case 3:
			printf("enter search string");
			scanf("%s",b);
			flag=str_remove((arr),b,size);
			if(flag==1)
			{
				size=size-1;
			}
			break;
		case 4:
			printf("enter order accsending(0) or desending(1)");
			scanf("%d",&flag);
			str_sort(arr,size,flag);
			break;
			
		case 5:
		
			for(int i=0;i<size;i++)
			{
		
				printf("\n %s \n ",*(arr+i));
			}
			break;
		case 6:
			return 0;
			break;
		default:
			printf("enter again");
		break;
	}
	}
	return 0;
}

