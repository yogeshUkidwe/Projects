#include<stdlib.h>
#include<stdio.h>
#include"ownlinklist.h"
struct node
{
	int data ;
	struct node* next;
};

int Length(struct node* head) 
{
	int count = 0;
	struct node* current = head;
	for (current = head; current != NULL; current = current->next)
	{
		count++;
		
	}
return(count);
}
void Push(struct node** headRef, int newData) 
{
	struct node* newNode =(struct node*) malloc(sizeof(struct node)); 
	newNode->data = newData; 
	newNode->next = (*headRef); 
	(*headRef) = newNode; 
}
int BuildOneTwoThree(int x)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	temp->next=head;
	head=temp;
	
	return 0;
}
void print1(struct node* printt)
{
	printf("\n list is :");
	for (; printt != NULL; printt=printt->next)
	{
		printf(" %d ",printt->data);
	}
}
void print()
{
	struct node* temp=head;
	printf("\n list is :");
	for (; temp != NULL; temp=temp->next)
	{
		printf(" %d ",temp->data);
	}
}
// 1.count
int count(struct node* head, int search)
{
	int count = 0;
	struct node* current = head;
	for (current = head; current != NULL; current = current->next)
	{
		if (current->data == search) 
		{
			count++;
		}
	}
	return count;
}
//2.nth position
int GetNth(struct node* head, int search ) 
{
	struct node* current = head;
	int count = 0; 
	for (current = head; current != NULL; current = current->next)
	{
		if (count == search) 
		{
			return(current->data);
		}
		count++;
	}
	return  count;
}
//3.delete list
void deletelist(struct node** headr) 
{
	struct node* current = *headr; 
	struct node* next;
	for (;current != NULL;current = next ) 
	{
		next = current->next; 
		free(current); 
	}
	*headr = NULL;
}
//4.pop
int pop(struct node** headr) 
{
	int result;
	struct node* temp = *headr;
	result = temp->data; 
	*headr = temp->next; 
	free(temp); 
	return(result); 
}
//5.positionNth
void InsertNth(struct node** headr, int position, int data)
{
	struct node* temp1=(struct node*)malloc(sizeof(struct node));
	temp1->data=data;
	temp1->next=NULL;
	if(position==1)
	{
	temp1->next=head;
	head=temp1;
	return;
	}
	struct node* temp2=head;
	for(int i=0;i<position-2;i++)
	{
		temp2=temp2->next;
	}
	temp1->next=temp2->next;
	temp2->next=temp1;
}
//6.sortinsert
void SortedInsert(struct node** headr, struct node* y)
{
	if (*headr == NULL || (*headr)->data <= y->data) 
	{
		
		y->next = *headr;
		*headr = y;
	}
	
	else 
	{
		struct node* current = *headr;
		while (current->next!=NULL && current->next->data>y->data) 
		{
			
			current = current->next;
		}
		y->next = current->next;
		current->next = y;
	}
}
int BuildOne(int x)
{
	struct node* y1=(struct node*)malloc(sizeof(struct node));
	y1->data=x;
	y1->next=NULL;
	y1->next=y;
	y=y1;
	
	return 0;
}
//7.insertsort
void InsertSort(struct node** headr) 
{
	struct node* result = NULL; 
	struct node* current = *headr; 
	struct node* next;
	while (current!=NULL)
	{
		next = current->next;
		SortedInsert(&result, current);
		current = next;
	}
	*headr = result;
}
//8.append
void Append(struct node** aRef, struct node** bRef) 
{
	struct node* current;
	if (*aRef == NULL) 
	{ 
		*aRef = *bRef;
	}
	else 
	{
	current = *aRef;
	while (current->next != NULL) 
	{ 
		current = current->next;
	}
	current->next = *bRef; 
	}
	*bRef=NULL; 
}
//9.FrontBackSplit
void FrontBackSplit(struct node* source,struct node** frontr, struct node** backr) 
{

	int len = Length(source);
	int i;
	struct node* current = source;

	if (len < 2)
	{
		*frontr = source;
		*backr = NULL;
	}
	else 
	{
		int count = (len-1)/2; 
		for (i = 0; i<count; i++)
		{
			current = current->next;
		}
		*frontr = source;
		*backr = current->next;
		current->next = NULL;
	}
}
//10.RemoveDuplicates
void RemoveDuplicates(struct node* head) 
{
	struct node* current = head;

	if (current == NULL) 
		return; 
	while(current->next!=NULL) 
	{
	if (current->data == current->next->data) 
	{
		struct node* nextNext = current->next->next;
		free(current->next);
		current->next = nextNext;
	}
	else 
	{
	current = current->next; 
}
}
}
//11.Movenode
void Movenode(struct node** dest, struct node** source) 
{
	struct node* newnode = *source; 
	*source = newnode->next; 
	newnode->next = *dest; 
	*dest = newnode; 
	
}
//12.Alternatingspli
void Alternatingsplit(struct node* source,struct node** ar, struct node** br)
{

	struct node* a = NULL; 
	struct node* b = NULL;
	struct node* current = source;
	while (current != NULL) 
	{
	Movenode(&a, &current); 
		if (current != NULL) 
		{
		Movenode(&b, &current); 
		}
	}
	*ar = a;
	*br = b;

}
//13.Shufflemerge
struct node* Shufflemerge(struct node* a, struct node* b) 
{
	struct node dummy;
	struct node* tail = &dummy;
	dummy.next = NULL;
	while (1) 
	{
		if (a==NULL) 
		{
			tail->next = b;
			break;
		}
		else if (b==NULL) 
		{
			tail->next = a;
			break;
		}
		else 
		{
			Movenode(&(tail->next), &a);
			tail = tail->next;
			Movenode(&(tail->next), &b);
			tail = tail->next;
		}
	}
return(dummy.next);
}
//14 .Sortedmerge
struct node* Sortedmerge(struct node* a, struct node* b) 
{
	struct node dummy;
	struct node* tail = &dummy; 
	dummy.next = NULL;
	while (1) 
	{
		if (a == NULL) 
		{ 
			tail->next = b;
			break;
		}
		else if (b == NULL) 
		{
		tail->next = a;
		break;
		}
		if (a->data <= b->data) 
		{
		Movenode(&(tail->next), &a);
		}
		else 
		{
		Movenode(&(tail->next), &b);
		}
		tail = tail->next;
	}
	return(dummy.next);
}
//15.metgesort
void MergeSort(struct node** headr) 
{
	struct node* head = *headr;
	struct node* a;
	struct node* b;
	if ((head == NULL) || (head->next == NULL)) 
	{
	return;
	}
	FrontBackSplit(head, &a, &b); 
	MergeSort(&a); 
	MergeSort(&b);
	*headr = Sortedmerge(a, b); 
}
//16.SortedIntersect
int BuildOne1(int x)
{
	struct node* y1=(struct node*)malloc(sizeof(struct node));
	y1->data=x;
	y1->next=NULL;
	y1->next=y3;
	y3=y1;
	
	return 0;
}
struct node* SortedIntersect(struct node* a, struct node* b) 
{
	struct node dummy;

	struct node* tail = &dummy;
	dummy.next = NULL;
	while (a!=NULL && b!=NULL)
	{
		if (a->data == b->data) 
		{
			Push((&tail->next), a->data);
			BuildOne1(a->data);
			tail = tail->next;
			a = a->next;
			b = b->next;
		}
		else if (a->data >b->data) 
		{ 
			a = a->next;
		}
		else 
		{
			b = b->next;
		}	
	}
	return(dummy.next);
}
//17.Reverse
void reverse1(struct node** headr) 
{
	struct node* result = NULL;
	struct node* current = *headr;
	struct node* next;
	while (current != NULL) 
	{
		next = current->next; 
		current->next = result; 
		result = current;
		current = next;
	}
	*headr = result;
}