#ifndef ownlink
#define ownlink
struct node* head;
struct node* y;
struct node* y3;
int BuildOne(int x);
int BuildOne1(int x);
void Push(struct node** headRef, int newData) ;
struct node *insert (struct node *head1,int a);
int count(struct node* head, int searchFor);
int BuildOneTwoThree(int x);
void print();
void print1(struct node* printt);
void FrontBackSplit(struct node* source,struct node** frontr, struct node** backr) ;
int Length(struct node* head) ;
int GetNth(struct node* head, int index) ;
void deletelist(struct node** headr) ;
int pop(struct node** headr) ;
void InsertNth(struct node** headr, int postion, int data);
void SortedInsert(struct node** headr, struct node* newnode);
void InsertSort(struct node** headr) ;
void Append(struct node** ar, struct node** br) ;
void RemoveDuplicates(struct node* head) ;
void Movenode(struct node** dest, struct node** source) ;
void Alternatingsplit(struct node* source,struct node** ar, struct node** br);
struct node* Shufflemerge(struct node* a, struct node* b);
struct node* Sortedmerge(struct node* a, struct node* b);
void MergeSort(struct node** headr);
struct node* SortedIntersect(struct node* a, struct node* b) ;
void reverse1(struct node** headr) ;
#endif