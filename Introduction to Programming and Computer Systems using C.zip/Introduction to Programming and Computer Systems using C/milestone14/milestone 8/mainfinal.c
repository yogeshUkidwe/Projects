#include<stdio.h>
#include<stdlib.h>
#include"ownvoid.h"

int main()
{
	int choice ,i,flag=1,n=0;
	printf("enter choice \n 1.int \n 2.float \n 3.char \n 4.string \n ");
	scanf("%d",&choice);
	printf("enter th limit ");
	scanf("%d",&n);
	int *arr=(int*)malloc(n*sizeof(int));
	float *arr1=(float*)malloc(n*sizeof(float));
	char *arr2=(char*)malloc(n*sizeof(char));
	char *arr3[10] = {"aaa","ccc","ddDd","aaaaa","bbb","zzz"};	


switch(choice)
{
	case 1:
		printf("enter number for sorting");
		for(i=0;i<n;i++)
		{
		scanf("%d",arr+i);
		}
		printf("enter assending(1) /descending(2)");
		scanf("%d",&flag);
		ysort(arr,n,sizeof(int),int_compare,flag);
		for(i=0;i<n;i++)
		{
			printf(" %d",arr[i]);
		}
	break;
	case 2:
		printf("enter number for sorting");
		for(i=0;i<n;i++)
		{
		scanf("%f",arr1+i);
		}
		printf("enter assending(1) /descending(2)");
		scanf("%d",&flag);
		ysort(arr1,n,sizeof(float),float_compare,flag);
		for(i=0;i<n;i++)
		{
			printf(" %f",arr1[i]);
		}
	break;
	case 3:
		printf("enter character for sorting");
		for(i=0;i<n;i++)
		{
		scanf(" %c",arr2+i);
		}
		printf("enter assending(1) /descending(2)");
		scanf("%d",&flag);
		ysort(arr2,n,sizeof(char),char_compare,flag);
		for(i=0;i<n;i++)
		{
			printf(" %c",*(arr2+i));
		}
	break;
	case 4:
		printf("enter assending(1) /descending(2)");
		scanf("%d",&flag);
	     ysort(arr3,6,sizeof(char*),string_comp,flag);
		for(i=0;i<6;i++)
		{
			printf("%s \n",*(arr3+i));
		}
	break;
	default:
	   printf("wrong choice");
	   break;
}
	
}
