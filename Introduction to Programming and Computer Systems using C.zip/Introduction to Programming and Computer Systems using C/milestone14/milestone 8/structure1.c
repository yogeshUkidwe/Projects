#include<stdio.h>
#include"strucure1.h"
#include <string.h>
#include<stdlib.h>
void printBook( struct Books book );
int str_copy1(char str1[], char str2[]);


int main() {

   struct Books Book1;        /* Declare Book1 of type Book */
   struct Books Book2;        /* Declare Book2 of type Book */
 
   /* book 1 specification */
  str_copy1( Book1.title, "C Programming");
   str_copy1( Book1.author, "Nuha Ali"); 
   str_copy1( Book1.subject, "C Programming Tutorial");
   Book1.book_id = 6495407;

   /* book 2 specification */
  str_copy1( Book2.title, "Telecom Billing");
   str_copy1( Book2.author, "Zara Ali");
  str_copy1( Book2.subject, "Telecom Billing Tutorial");
   Book2.book_id = 6495700;
 
   /* print Book1 info */
   printBook( Book1 );

   /* Print Book2 info */
   printBook( Book2 );

   return 0;
}

void printBook( struct Books book ) {

   printf( "Book title : %s\n", book.title);
   printf( "Book author : %s\n", book.author);
   printf( "Book subject : %s\n", book.subject);
   printf( "Book book_id : %d\n", book.book_id);
}
int str_copy1(char str1[], char str2[])
{
	
	int flag =0;
	for( int i = 0; str2[i] != '\0'; i++)
	{
		
			flag=1;
			str1[i]=str2[i];
			printf("%c",str1[i]);
	
	}
	if(flag==1)
	{
		printf("\n string copied \n");
	}
	int len=length(str1);
	if(len==0)
	{
		printf("-1 error found");
	}
	return 0;
	
}