#ifndef ownvoid
#define ownvoid
int length(char *str);
void *mem_copy(void *dest, const void *src, unsigned int n);
int str_compare(char *str1, char *str2);
void ysort(void *array,int length, int element_size,int compare(void*,void*),int flag );
int int_compare( void *a, void *b);
int string_comp(void *a,void *b);
int float_compare(void *a,void *b);
int char_compare( void *a1, void *b1);
#endif