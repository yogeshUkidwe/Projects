#ifndef copy
#define copy
int str_copy2(char str1[], char str2[]);
int str_compare(char str1[], char str2[]);
int length1(char *str);
int str_find(char *str1, char str2);
int str_find_substring1(char *str1, char *str2);
#endif