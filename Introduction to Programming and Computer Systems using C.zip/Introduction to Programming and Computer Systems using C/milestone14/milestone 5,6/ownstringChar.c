#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"ownstringChar.h"


int length(const char *str)
{ 
	int i;
	for( i = 0; str[i] != '\0'; i++)
	{
		
	}
	return (i);
	
}
char* str_copy(const char *str4 )
{
	
	int flag =0;
	int n=length(str4);
	char *str1 = (char*) malloc(n * sizeof(char));
	for( int i = 0; str4[i] != '\0'; i++)
	{
		
			flag=1;
			
			str1[i]=str4[i];
			printf("%c",str1[i]);
	
	}
	if(flag==1)
	{
		printf("\n string copied \n");
	}
	free(str1);
	return 0;
}
int str_copy1(char str1[], char str2[])
{
	
	int flag =0;
	
	for( int i = 0; str2[i] != '\0'; i++)
	{
		
			flag=1;
			str1[i]=str2[i];
			printf("%c",str1[i]);
	
	}
	if(flag==1)
	{
		printf("\n string copied \n");
	}
	int len=length(str1);
	if(len==0)
	{
		printf("-1 error found");
	}
	return 0;
	
}
char** str_tokenize(char *str, char c)
{
	int last;
	for( int i = 0; str[i] != '\0'; i++)
	{
		
		if(str[i]==c)
		{
			
			printf("\n");
			str[i]='\0';
			
		}
		else 
		{
		str[i]=str[i];
		
		}
		
		printf("%c",str[i]);
		last=i;
	}
	printf("\n%c\n",str[last+1]);		
		
return 0;
}
void *mem_copy(void *dest, const void *src, unsigned int n)
{

		char *csrc = (char*)src;
		 char *cdest = (char*)dest;
		
		if(NULL == src) 
		{
				return NULL;
				 
		} 
		else 
		{
			for( int i = 0; i<n; i++)
			{
					cdest[i]=csrc[i];
					printf("%c",cdest[i]);
			        
			}
			
			free(cdest);
		}

  return cdest;
}
