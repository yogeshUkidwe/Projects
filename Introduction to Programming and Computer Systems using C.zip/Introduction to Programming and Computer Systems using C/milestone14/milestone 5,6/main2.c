#include<stdio.h>
#include<stdlib.h>
#include"ownstringChar.h"
void clear(void)
{
		char ch;
		while((ch=getchar())!='\n' && ch != EOF);
}
int main()
{
	int choice;
	char c;
	char str2[100]="";
	char str8[100];
	char *str3[100];

	while(1)
	{
		printf("1. Copy one string into another c  \n");
		printf("2. function breaks str based on the token \n");
		printf("3. copies n bytes from memory area src to memory area dest \n");
		printf("4. Exit\n");
		printf("Enter the choice:");
		
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
					
					printf("\n enter string2 ");
					scanf("%s",str2);
					//int n=length(str2);
					clear();
					str_copy(str2);
				break;
			case 2:
					
					printf("enter string2 ");
					scanf("%s",str2);
					clear();
					printf("enter the character");
					scanf("%c",&c);
					str_tokenize( str2,  c);
					break;
					
			case 3:
					 
					 
					printf("enter a string");
					scanf("%s",str8);
					unsigned int n=length(str8);
					mem_copy(str8+10,str8,n);
					
					break;
			
			case 4:
					return 0;
			default:
					printf("wrong choice reenter \n");
				break;
		}
	}
}