#ifndef copy
#define copy

int length(const char *str);
char** str_tokenize(char *str, char c);
void *mem_copy(void *dest, const void *src, unsigned int n);
int str_copy1(char str1[], char str2[]);
char* str_copy(const char *str4);

#endif