#include<stdio.h>
#include "ownmath.h"
int main()
{
	unsigned int n ;
	printf("enter the number");
	scanf("%u",&n);
	fact(n);
}
