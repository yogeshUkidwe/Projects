#include <stdio.h>
#include "ownmath.h"
int main()
{
	int num1;
	printf("enter the number ");
	scanf("%d",&num1);
	
	printf("prime fctors are :\n");
	prime_factors(num1);
	
	return 0;
	
}

	
