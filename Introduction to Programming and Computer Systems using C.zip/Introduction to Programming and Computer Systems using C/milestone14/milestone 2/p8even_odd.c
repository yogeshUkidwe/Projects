#include <stdio.h>
#include "ownmath.h"
int main()
{
	int num2;
	printf("enter the number");
	scanf("%d",&num2);
	printf("prime fctors are :\n");
	even_odd(num2);
	return 0;
	
}
