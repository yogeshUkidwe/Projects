#include<stdio.h>
#include "ownmath.h"
int main()
{
	double rate,FV;
	unsigned int nperiods;
	printf("enter rate for present value");
	scanf("%lf",&rate);
	printf("enter nperiods for present value");
	scanf("%u",&nperiods);
	printf("enter  future value");
	scanf("%lf",&FV);
	PV( rate, nperiods, FV);
	return 0;
}

