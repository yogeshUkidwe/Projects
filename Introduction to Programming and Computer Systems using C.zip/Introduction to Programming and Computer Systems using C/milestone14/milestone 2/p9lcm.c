#include <stdio.h>
#include "ownmath.h"
int main()
{
	int num1,num2;
	printf("enter the number1 ");
	scanf("%d",&num1);
	printf("enter the number2 ");
	scanf("%d",&num2);
	LCM(num1,num2);
	return 0;
	
}
