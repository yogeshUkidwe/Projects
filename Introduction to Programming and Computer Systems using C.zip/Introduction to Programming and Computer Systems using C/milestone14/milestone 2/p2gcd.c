#include<stdio.h>
#include "ownmath.h"
int main()
{
	int x, y;
	printf("enter the x ");
	scanf("%d",&x);
	printf("eneter y ");
	scanf("%d",&y);
	int result=gcd(x, y);
	printf("result is %d",result);
	return 0;
}
