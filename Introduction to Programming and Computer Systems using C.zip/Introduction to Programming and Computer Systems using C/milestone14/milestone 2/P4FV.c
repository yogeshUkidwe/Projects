#include<stdio.h>
#include "ownmath.h"
int main()
{
	double PV,rate;
	unsigned int nperiods;
	printf("enter rate for future value");
	scanf("%lf",&rate);
	printf("enter nperiods for future value");
	scanf("%u",&nperiods);
	printf("enter PV for future value");
	scanf("%lf",&PV);
	FV( rate, nperiods, PV);

}

