#ifndef ownmath
#define ownmath
int even_odd(int num2);
int factors(int num);
unsigned int fact(unsigned int n);
int fibonacci(int n);
double FV(double rate, unsigned int nperiods, double PV);
double power(double x, int n) ;
int gcd(int x,int y) ;
int LCM(int num1,int num2);
int is_prime(unsigned int num);
int prime_factors(int num1);
double PV(double rate, unsigned int nperiods, double FV);
#endif