#include<stdio.h>
#include"ownmath.h"
int main()
{
	double x;
	int n;
	printf("enter the x ");
	scanf("%lf",&x);
	printf("eneter n ");
	scanf("%d",&n);
	
	printf("result is %lf",power( x,  n));
	
	return 0;
}






