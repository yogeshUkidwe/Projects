#include<stdio.h>
#include "ownmath.h"
int main()
{
int n;
printf("enter the number :");
scanf("%d",&n);
printf("Fibonacci series ");

fibonacci(n);
return 0;
}


