#include<stdio.h>
#include "ownmath.h"
unsigned int fact(unsigned int n)
{
	int factorial = 1;
    if (n == 0)
    {
        return(factorial);
    }
    else
	{
		for(int i=1;i<=n;++i)
		{
			factorial*=i;
		}
	}
	return(factorial);
	return 0;
}
int even_odd(int num2)
{
	if(num2%2==0)
	{
		printf("%d is even number",num2);
	}
	else 
	{
		printf("%d is odd number",num2);
		}
	return 0;	
}
int factors(int num)
{
	for( int i=1;i<=num;i++)
	{
		if(num%i==0)
		{
			printf(" %d \n",i);
        }
		
	}
	return 0;
}
int prime_factors(int a)
{
int i;
		for(i=1;i<a;i++)
	{
	    if(a%i==0)
		{
		printf("%d\n",i);
		}
	}
	return 0;
}	
int fibonacci(int n)
{
	int i, n1=0,n2=1,n3;

	for (i=1;i<=n;++i)
	{
		printf("%d, ",n1);
        n3= n1 + n2;
        n1 = n2;
        n2 = n3;
	}
	return 0;
}
double FV(double rate, unsigned int nperiods, double PV)
{

	double fv,b;
	b=(rate/100)+1;
	fv=PV*power(b,nperiods);
	printf ("FV IS %lf",fv);
	return 0;
	
}
double power(double x, int n) 
{
	double result=1;
	 while (n != 0)
    {
        result*= x;
        --n;
    }
	return result;
	return 0;
}
double PV(double rate, unsigned int nperiods, double FV)
{
	double pv,a;
	a=(rate/100)+1;
	 pv=FV/power(a,nperiods);
	printf ("PV IS %lf",pv);
	return 0.00;
}
int gcd(int x,int y)
{
	int result=0;
    for( int i=1; i <= x && i <= y; ++i)
    {
	
        if(x%i==0 && y%i==0)
		{
          result =i;
		 
		} 
		
    }
	return result;
	return 0;
}
int LCM(int num1,int num2)
{
	int maxnum = (num1>num2) ? num1 : num2;

    while(1)
    {
        if( maxnum%num1==0 && maxnum%num2==0 )
        {
            printf("The LCM of %d and %d is %d.", num1, num2,maxnum);
            break;
        }
        ++maxnum;
    }
    return 0;
}
int is_prime(unsigned int num)
{
	for (int i=2;i<num;i++)
	{
		if(num%i==0)
		{
			printf("%u is not prime number\n",num);
			return 0;
		
			break;
		
		}
		else
		{
			printf("%u is prime number\n",num);
			return 1;
			break;
		
		}
		
	}
	return 0;
}

