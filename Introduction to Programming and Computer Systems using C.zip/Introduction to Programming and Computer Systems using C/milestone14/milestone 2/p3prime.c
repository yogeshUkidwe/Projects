#include<stdio.h>
#include "ownmath.h"
int main()
{
unsigned int num;
printf("enter the number ");
scanf("%u",&num);
printf("%u",is_prime(num));
return 0;
}
