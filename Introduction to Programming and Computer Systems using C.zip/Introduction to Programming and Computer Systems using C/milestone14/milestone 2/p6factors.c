#include <stdio.h>
#include "ownmath.h"
int main()
{
	int num;
	printf("enter the number");
	scanf("%d",&num);
	
	printf("fctors are :\n");
	factors(num);
	
	return 0;
	
}
