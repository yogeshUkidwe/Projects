#include<stdio.h>
#include "ownmath.h"
int main()
{
	int n,r,nr,ans;
	printf("enter value of n");
	scanf("%d",&n);
	printf("enter value of r");
	scanf("%d",&r);
	nr=n-r;
	ans=(fact(n)/fact(nr));
	printf("npr is %d",ans);
}
