#ifndef ownlink
#define ownlink
struct node* head;
char BuildOneTwoThree(struct node* y,char* word,char* meaning);
void print1(struct node* printt);
char wordsearch(struct node* head, char* search ) ;
int str_compare1(char *str1, char *str2);
void deleteword(struct node** headr,char* remove) ;
void Movenode(struct node** dest, struct node** source) ;
void printdict(struct node** printt);
#endif