#include<stdlib.h>
#include<stdio.h>
#include"ownrecursion.h"
int main()
{
	int choice;
	while(1)
	{
	char* word=(char*)malloc(sizeof(char*));
	char* meaning=(char*)malloc(sizeof(char*));
	printf("enter choice ");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:
		printf("enter a word :");
		scanf("%s",word);
		printf("enter meaning :");
		scanf("%s",meaning);
		BuildOneTwoThree(head,word,meaning);
		
		print1(head);
		
		break;
	case 2:
		reverse(&head);
		print1(head);
		break;
		
	case 3:
		return 0;
		break;
	}
	}
}
