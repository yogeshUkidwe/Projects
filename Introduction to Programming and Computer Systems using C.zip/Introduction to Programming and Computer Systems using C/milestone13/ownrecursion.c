#include<stdlib.h>
#include<stdio.h>
#include"ownrecursion.h"


char BuildOneTwoThree(struct node* y,char* word1,char* meaning1)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->word=word1;
	temp->meaning=meaning1;
	temp->next=head;
	head=temp;
	
	return 0;
}
void print1(struct node* printt)
{
	int i=1;
	printf("\n list is :\n");
	for (; printt != NULL; printt=printt->next)
	{
		printf("%s =",printt->word);
		printf("%s \n",printt->meaning);
		i++;
	}
	return ;
}

 void reverse(struct node **headr)
{
 struct node *temp=*headr;
 struct node *new=temp->next;;
  
 if(*headr==NULL)
 {
   return;
 }
 
  if(new==NULL)
  {     
    
         return;
  }
  
   reverse(&(new));
  temp->next->next=temp;
  temp->next=NULL;
  *headr=new;
}  


