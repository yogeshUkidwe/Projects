#ifndef ownlink
#define ownlink
struct node* head;
struct node
{
	char* word ;
	char* meaning;
	struct node* next;
};
char BuildOneTwoThree(struct node* y,char* word1,char* meaning1);
void print1(struct node* printt);
 void reverse(struct node **headr);
#endif