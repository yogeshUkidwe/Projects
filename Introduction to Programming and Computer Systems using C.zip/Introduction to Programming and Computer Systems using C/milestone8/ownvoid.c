#include<stdio.h>
#include<stdlib.h>
#include"ownvoid.h"
int length(char *str)
{ 
	int i;
	for( i = 0; str[i] != '\0'; i++)
	{
		
	}
	return (i);
	return 0;
	
}
int int_compare( void *a1, void *b1)
{
	int *a=(int*)a1;
	int *b=(int*)b1;
	if(*a>*b)
	{
		return 1;
		}else
		{ 
			return -1;
			}
	
}

int float_compare(void *a,void *b)
{
  float *f1=(float *)a;
  float *f2=(float *)b;
 if(*f1>*f2)
	{
		return 1;
		}else
		{ 
			return -1;
			}
	
  
}
int char_compare( void *a1, void *b1)
{
	char *a=(char*)a1;
	char *b=(char*)b1;
	if(*a>*b)
	{
		return 1;
		}else
		{ 
			return -1;
			}
	
}
int string_comp(void *a,void *b)
{
  char **y1=(char **)a;
  char **y2=(char **)b;
  return str_compare(*y1,*y2);
  
}
void ysort(void *array1,int length, int element_size,int compare(void*,void*),int flag)
{
	int i=0,j=0;
	void *temp = malloc(element_size);
	char *array=(char *)array1;
	for(i=0;i<length;i++)
	{
		for(j=i+1;j<length;j++)
		{	
			if(flag==1)
			{
			if(compare((array + (i*element_size)),(array+(j*element_size)))>0)
				{
					mem_copy(temp, (array+(i*element_size)), element_size);
					mem_copy((array+(i*element_size)), (array+(j*element_size)),element_size);
					mem_copy((array+(j*element_size)),temp, element_size);
				}
			}
			else if(flag==2)
			{
	
			if(compare((array + (i*element_size)),(array+(j*element_size)))<0)
				{
					mem_copy(temp, (array+(i*element_size)), element_size);
					mem_copy((array+(i*element_size)), (array+(j*element_size)),element_size);
					mem_copy((array+(j*element_size)),temp, element_size);
					
				}
			
			}
		}
	
	}

}

void *mem_copy(void *dest, const void *src, unsigned int n)
{
	int i=0;
	char *source=(char *)src;
	char *destination=(char *)dest;
	for(i=0;i<n;i++)
	{  
		destination[i]=source[i];
	}
	return destination; 
} 

	
int str_compare(char *str1, char *str2)
{
	int flag=0,mlag=0,lag=0,n=0;
	int len =length(str1);
	int len1=length(str2);
	if(len>len1)
	{
		return 1;
	}
	else if(len<len1)
	{
		return -1;
	}
	else if (len==len1)
	{
		len =n;
	}
		
	for( int i = 0; i<=n; i++)
	{
		if(str1[i]>str2[i])
		{
			flag++;
		}
		else if(str1[i]<str2[i])
		{
			mlag++;
		}
		else 
		{
			lag++;
		}
	}
	if (lag>flag && lag>mlag)
	{
		return 3;
	}
	else if (flag>mlag)
	{
		return 1;
	}
	else if(flag<mlag)
	{
		return -1;
	}
	else
	{
	if(str1==NULL || str2==NULL )
	{
		printf("-1 error found \n");
	}
	return 9;
	}
	return 0;
}