#include<stdlib.h>
#include<stdio.h>
#include"ownlinklist.h"
int main()
{
	int x,n,search,count1,choice,lastNode,num1,position,n1;
	head=NULL;
	
	
	printf("how many numbwe \n");
	scanf(" %d",&n);
	struct node* y2;
	for(int i=0;i<n;i++)
	{
	printf("\n enter the number \n");
	scanf("%d",&x);
	BuildOneTwoThree(x);
	print();
	}
	while(1)
	{
	printf(" \n 1.count \n 2.nth number \n 3.delete \n 4.pop \n 5.insertNth \n 6.sortedlist \n 7.insertsort \n 8.append \n 9.FrontBackSplit \n 10.RemoveDuplicates \n 11.Movenode \n 12.Alternatingsplit \n 13.Shufflemerge \n 14.Sortedmerge \n 15.metgesort \n 16.SortedIntersect \n 17.reverse \n 18.exit \n");
	printf("enter your choice");
	scanf("%d",&choice);
	if(sizeof(choice) != 1)
	{
		break;
	}
	switch(choice)
	{
	case 1:
		printf("\n enter number for search :");
		scanf("%d",&search);
		
		count1=count(head,search);
		printf("%d ",count1);
		print();
	break;
	case 2:
		printf("\n enter number for position");
		scanf("%d",&num1);
		lastNode=GetNth(head,num1);
		printf("%d ",lastNode);
	break;
	case 3:
		deletelist(&head);
		printf("deleted successfully");
		return 0;
		
	break;
	case 4:
	     printf("%d",pop(&head));
		 print();
		
	break;
	case 5:
		printf("enter position");
		scanf("%d",&position);
		printf("enter data");
		scanf("%d",&num1);
		InsertNth(&head,position,num1);
		print();
	break;
	case 6:
		printf("enter the number");
		scanf("%d",&num1);
		BuildOne(num1);
		SortedInsert(&head,y);
		print();
	break;
	case 7:
		InsertSort(&head);
		print();
	break;
	case 8:
		printf("how many numbwe \n");
		scanf(" %d",&n1);
		for(int i=0;i<n1;i++)
		{
		printf("\n enter the number \n");
		scanf("%d",&x);
		BuildOne(x);
		}
		Append(&head,&y);
		print(y);
	break;
	case 9:
		print();
		FrontBackSplit(head,&y,&y2);
		
		print1(y);
		print1(y2);
	break;
	case 10:
		InsertSort(&head);
		RemoveDuplicates(head);
		print();
	break;
	case 11:
		printf("how many numbwe \n");
		scanf(" %d",&n1);
		for(int i=0;i<n1;i++)
		{
		printf("\n enter the number \n");
		scanf("%d",&x);
		BuildOne(x);
		}
		Movenode(&head,&y);
		print();
		print1(y);
	break;
	case 12:
		print();
		Alternatingsplit(head,&y,&y2);
		print1(y);
		print1(y2);
		break;
	case 13:
		
		printf("how many numbwe \n");
		scanf(" %d",&n1);
		for(int i=0;i<n1;i++)
		{
		printf("\n enter the number \n");
		scanf("%d",&x);
		BuildOne(x);
		
		}
		
		Shufflemerge(head,y);
		print1(y);
		print();
	break;
	case 14:
		print();
		printf("how many numbwe \n");
		scanf(" %d",&n1);
		for(int i=0;i<n1;i++)
		{
		printf("\n enter the number \n");
		scanf("%d",&x);
		BuildOne(x);
		printf("list are");
		print1(y);
		}
		Sortedmerge(head,y);
		InsertSort(&head);
		print1(head);
	break;	
	case 15:
		MergeSort(&head);
		print();
	break;
	case 16:
		printf("how many numbwe \n");
		scanf(" %d",&n1);
		for(int i=0;i<n1;i++)
		{
		printf("\n enter the number \n");
		scanf("%d",&x);
		BuildOne(x);
		print1(y);
		}
		print();
		SortedIntersect(head,y); 
		print1(y3);
	break;
	case 17:
		reverse1(&head);
		print();
	break;
	case 18:
		return 0;
	default:
	 printf("wrong choice reenter");
	break;
	}		
}

}
