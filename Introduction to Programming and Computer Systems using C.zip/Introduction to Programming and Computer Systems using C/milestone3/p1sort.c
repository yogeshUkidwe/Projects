#include<stdio.h>
#include<conio.h>
int main()
{
	int n,flag,temp;
	printf("enter array size :");
	scanf("%d",&n);
	printf("enter the elements for array \n");
	int arr[n];
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&arr[i]);
	}
printf("enter the assrnding(1) or decending(0) order  ");
	scanf("%d",&flag);
	if(flag==1)
	{
		for(int i=1;i<=n; i++)
		{
			for(int j=i+1; j<=n; j++)
			{
				if(arr[i] > arr[j])
				{
					
					temp     = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
					printf("\ni=%d ",i);
					printf("\nj=%d ",j);
					printf("\na[i]=%d ",arr[i]);
					printf("\na[j]=%d  ",arr[j]);
				        printf("\ntemp=%d ",temp);
				}
			}
			printf("%d \n",arr[i]);
		}

	}
	else if(flag==0)
	{
		for(int i=1; i<=n; i++)
		{
			for(int j=i+1; j<=n; j++)
			{
				if(arr[i] < arr[j])
				{
					temp  = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
			printf("%d \n",arr[i]);
		}
	}
	else
	{
	printf("enter o or 1");
	}
	for(int i=1;i<=n;i++)
	{
		printf(" %d ",arr[i]);
	}
	return 0;
 
}