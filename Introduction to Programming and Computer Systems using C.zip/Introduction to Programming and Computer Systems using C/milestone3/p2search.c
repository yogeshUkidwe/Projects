#include<stdio.h>
#include<conio.h>
int main()
{
	int n,search;
	printf("enter array size : ");
	scanf("%d",&n);
	printf("enter the elements for array \n");
	int arr[n];
	for(int i=0;i<=n-1;i++)
	{
		scanf("%d",&arr[i]);
	}
	printf("\nEnter the element to search within the array: ");
    scanf("%d", &search);
 
    for(int i=0; i<=n-1; i++)
    {
       
        if(arr[i]==search)
        {
            printf("\n %d is found at position %d", search, i+1);
			flag=1;
            break;
		}
		
	}
	else
		{
			printf("%d is not in array",search);
			
		}
	return 0;

}