#include<stdio.h>
#include <stdlib.h>

int main()
{
	int choice,num1,n,flag=0;
	
	printf("enter array size :");
	scanf("%d",&n);
	printf("enter the elements for array \n");
	int arr[n];
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&arr[i]);
	}
	
	printf(" 1. Add an element to the Array the application should not allow the user to enter  the same number twice \n 2. Search if an element exists in the array \n 3. Remove an element from the array \n 4. Sort the array  \n 5. Print all elements in the array \n 6. Exit \n");
	printf("enter your choice  ");
	scanf("%d",&choice);
	
//	1.Add an element to the Array the application should not allow the user to enter
	if(choice==1)
	{
		
		printf("\nenter the number which is add in array \n");
		scanf("%d",&num1);
		int *p;
		p=&num1;
		for(int i=1;i<=n;i++)
		{
	      
			if(arr[i]==*p)
			{
				flag=1;
				
				printf("alresdy exists \n");
				
				break;
				
			}
		
			
		}
		if(flag==0)
		{
			arr[n+1]=*p;
			for(int i=1;i<=n+1;i++)
			{
				printf("%d \t",arr[i]);
			}
		    printf("element %d inserted \n",*p);
		}
		main();
	}
// 2. Search if an element exists in the array \n 3. Remove an element from the array
    else if(choice==2)
	{
		int search;
		printf("\nEnter the element to search within the array: ");
		scanf("%d", &search);
		for(int i=1; i<=n; i++)
		{
			if(arr[i]==search)
			{
				flag=1;
				printf("\n %d is found at position %d \n", search, i);
				break;
			}
		
		}
		if(flag==0)
		{
			printf("%d is not in array \n",search);
			
		}
	 main();
	}
//3. Remove an element from the array
	else if(choice==3)
	{
		int remove,found;
		printf("\nEnter the element to remove within the array: ");
		scanf("%d", &remove);
	
		for (int i = 1; i < n; i++)
		{
			if (arr[i] == remove)
			{
				flag = 1;
				found = i;
				break;
			}
		}
		if (flag == 1)
		{
			for (int i = found; i <  n ; i++)
			{
				arr[i] = arr[i + 1];
			}
			printf("%d is deleted from %d position \n",remove,found);
			for (int i = 1; i < n ; i++)
			{
				printf("%d\n", arr[i]);
			}
		}
		else
		{
			printf("Element %d is not found in the array\n", remove);
		}
		main();
	}
// 4. Sort the array
	else if(choice==4)
	{
		int temp,flag=1;
		printf("enter the assrnding(1) or decending(2) order ");
		scanf("%d",&flag );
		if(flag==1 )
		{
			for(int i=1;i<=n; i++)
			{
				for(int j=i+1; j<=n; j++)
				{
					if(arr[i] > arr[j])
					{
						temp     = arr[i];
						arr[i] = arr[j];
						arr[j] = temp;
					}
				}
				printf("%d \n",arr[i]);
			}
		
		}
		else if(flag==2 )
		{
			for(int i=1; i<=n; i++)
			{
				for(int j=i+1; j<=n; j++)
				{
					if(arr[i] < arr[j])
					{
						temp  = arr[i];
						arr[i] = arr[j];
						arr[j] = temp;
					}
				}
				printf("%d \n",arr[i]);
			}
		}
		else
		{
			printf("enter o or 1 \n");
		}
		main();

	}
//5. Print all elements in the array
	else if(choice==5)
	{
		for(int i=1;i<=n;i++)
		{
			printf("%d \n",arr[i]);
		}
		main();
	}
//6.exit
    else if(choice==6)
	{
		exit(0);
	}
   else
	{
		printf("Invalid Option. Please try again  \n ");
		main();
	}
}
	

