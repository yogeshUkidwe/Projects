#include<stdio.h>
#include<stdlib.h>
#include"ownstring.h"


int length(char *str)
{ 
	int i;
	for( i = 0; str[i] != '\0'; i++)
	{
		
	}
	//printf("%d  %d",sizeof(*str),sizeof(str[0]));
	//i=sizeof(str)/sizeof(str[0]);
	return (i);
	return 0;
	
}
int str_copy(char str1[], char str2[])
{
	
	int flag =0;
	for( int i = 0; str2[i] != '\0'; i++)
	{
		
			flag=1;
			str1[i]=str2[i];
			printf("%c",str1[i]);
	
	}
	if(flag==1)
	{
		printf("\n string copied \n");
	}
	int len=length(str1);
	if(len==0)
	{
		printf("-1 error found");
	}
	return 0;
	
}
int str_compare(char str1[], char str2[])
{
	int flag=0,mlag=0,lag=0;
	int len=length(str1);

	for( int i = 0; str1[i] != '\0'; i++)
	{
		if(str1[i]>str2[i])
		{
			flag++;
		}
		else if(str1[i]<str2[i])
		{
			mlag++;
		}
		else 
		{
			lag++;
		}
	}
	if (lag>flag && lag>mlag)
	{
		return 0;
	}
	else if (flag>mlag)
	{
		return 1;
	}
	else if(flag<mlag)
	{
		return -1;
	}
	else
	{
	if(len==0 )
	{
		printf("-1 error found \n");
	}
	return 9;
	}
	return 0;
}
int str_find(char *str1, char str2)
{
	int flag=0;

	for( int i = 0; str1[i] != '\0'; i++)
	{
		
		if(str1[i]==str2)
		{
			flag=1;
			return i;
			break;
			
		}
	}
	if(flag==0)
	{ 
		printf("not found \n");
		return -1;
	}
	return 0;
}


int str_find_substring1(char *str1, char *str2)
{
	int flag,i;
	int n1=length(str1);
	int n2=length(str2);
	if(n1==0 || n2==0)
	{
		printf("-1 error found \n");
	}
	for ( i = 0; i <= n1 - n2; i++)
    {
        for (int j = i; j < i + n2; j++)
        {
            flag = 1;
            if (str1[j] != str2[j - i])
            {
                flag = 0;
				
                break;
            }
        }
        if (flag == 1)
            break;
    }
	if (flag == 1)
	{
        printf("successfully matched \n");
		printf(" at %d position",i);
	}
    else
	{
	   printf("search unsuccessfull \n");
	}
	return 0;
	
}