#include<stdio.h>
#include<stdlib.h>
#include"ownstring.h" 
void clear(void)
{
		char ch;
		while((ch=getchar())!='\n' && ch != EOF);
}
int main()
{
	int choice;
	char str[100]="";
	char str1[100]="";
	char str2[100]="";
	char str3;
	printf("1. Find length of the string \n");
	printf("2. Copy one string into another \n");
	printf("3. Compare two strings \n");
	printf("4. Find charcater in string \n");
	printf("5. Find substring with position \n");
	printf("6. Exit\n");
	printf("Enter the choice:");
	printf("enter the choice");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:
			
			printf("enter string ");
			scanf("%s",str);
			clear();
			int len=length(str);
			if(len==0)
			{
				printf("invalid string \n");
			}
			else
			printf("%d \n",  len);
		main();
		break;
	case 2:
			
			printf("enter string2 ");
			scanf("%s",str2);
			clear();
			str_copy(str1,str2);
			main();
		break;
	case 3:
			
			printf("enter string1");
			scanf("%s",str1);
			clear();
			printf("enter string2 ");
			scanf("%[^\n]80s",str2);
			clear();
			int j=str_compare(str1,str2);
			if(j==1)
			{
				printf(" str1 is greater than str2 \n");
			}
			else if(j==-1)
			{
				printf(" str1 is less than str2 \n");
			}
			else if(j==0)
			{
				printf("strings are equal \n");
			}	
		main();
		break;
	case 4:
			
			printf("enter string1");
			scanf("%s",str1);
		    clear();
			printf("enter string2 ");
			scanf("%c",&str3);
			clear();
			int x=str_find(str1,str3);
			if(x!=-1)
			{
				printf("character found at %d position \n",x);
			}
			main();
		break;
	case 5:
			
			printf("enter string1 :");
			scanf("%s",str1);
			clear();
			printf("enter string2 :");
			scanf("%[^\n]80s",str2);
			clear();
			str_find_substring1(str1, str2);
			main();
		break;
	case 6:
			exit(0);
	default:
			printf("wrong choice reenter \n");
			main();
		break;
	}
}