#include<stdio.h>
#include"ownarray.h"
int searchf(int search,int n,int arr[])
{
	int flag=0;
	for(int i=0; i<=n-1; i++)
    {
       
        if(arr[i]==search)
        {
            printf("\n %d is found at position %d", search, i+1);
			flag=1;
            break;
		}
		
	}
	if(flag==0)
		{
			printf("%d is not in array",search);
			
		}
	return 0;

}

int sort(int flag,int n,int arr[])
{
	int temp;
if(flag==1)
	{
		for(int i=1;i<='n'; i++)
		{
			for(int j=i+1; j<='n'; j++)
			{
				if(arr[i] > arr[j])
				{
					temp     = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
			printf("%d \n",arr[i]);
		}

	}
	else if(flag==0)
	{
		for(int i=1; i<='n'; i++)
		{
			for(int j=i+1; j<='n'; j++)
			{
				if(arr[i] < arr[j])
				{
					temp  = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
			printf("%d \n",arr[i]);
		}
	}
	else
	{
	printf("enter o or 1");
	}
	return 0;
 
}