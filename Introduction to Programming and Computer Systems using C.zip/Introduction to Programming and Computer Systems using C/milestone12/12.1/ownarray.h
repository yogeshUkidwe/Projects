#ifndef ownarray
#define ownarray
int sort(int flag,int n,int arr[]);
int searchf(int search,int n,int arr[]);
#endif