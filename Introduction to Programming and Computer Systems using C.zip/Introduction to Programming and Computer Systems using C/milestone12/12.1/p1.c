#include<stdio.h>
#include <stdlib.h>
#include"ownarray.h"

int main()
{
	int choice,num1,n=0,flag=0;
	int arr[10];
	while(1)
	{
	printf(" 1. Add an element to the Array the application should not allow the user to enter  the same number twice \n 2. Search if an element exists in the array \n 3. Remove an element from the array \n 4. Sort the array  \n 5. Print all elements in the array \n 6.save to file \n 7.load file \n 8. Exit \n");
	printf("enter your choice  ");
	scanf("%d",&choice);
	
//	1.Add an element to the Array the application should not allow the user to enter
	if(choice==1)
	{
		
		printf("\nenter the number which is add in array \n");
		scanf("%d",&num1);
		int *p;
		p=&num1;
		for(int i=1;i<=n;i++)
		{
	      
			if(arr[i]==*p)
			{
				flag=1;
				
				printf("alresdy exists \n");
				
				break;
				
			}
		
			
		}
		if(flag==0)
		{
			n=n+1;
			arr[n]=*p;
			
			for(int i=1;i<=n;i++)
			{
				printf("%d \t",arr[i]);
			}
		    printf("element %d inserted \n",*p);
			
		}
	}
// 2. Search if an element exists in the array \n 
   else if(choice==2)
	{ 
	int search;
	printf("\nEnter the element to search within the array: ");
    scanf("%d", &search);
	  searchf( search, n, arr);
	 main();
	}
//3. Remove an element from the array
	else if(choice==3)
	{
		int remove,found;
		printf("\nEnter the element to remove within the array: ");
		scanf("%d", &remove);
	
		for (int i = 1; i < n; i++)
		{
			if (arr[i] == remove)
			{
				flag = 1;
				found = i;
				break;
			}
		}
		if (flag == 1)
		{
			for (int i = found; i <  n ; i++)
			{
				arr[i] = arr[i + 1];
			}
			printf("%d is deleted from %d position \n",remove,found);
			for (int i = 1; i < n ; i++)
			{
				printf("%d\n", arr[i]);
			}
		}
		else
		{
			printf("Element %d is not found in the array\n", remove);
		}
	}
// 4. Sort the array
	else if(choice==4)
	{
		
		 sort( flag, n,arr);

	}
//5. Print all elements in the array
	else if(choice==5)
	{
		for(int i=1;i<=n;i++)
		{
			printf("%d \n",arr[i]);
		}
	}
//6.To save the array in a file
	else if(choice==6)
	{
		
		FILE *fpointer;
		fpointer =fopen("arraylist.txt","w");
		for(int i=1;i<=n;i++)
		{
			fprintf(fpointer,"%d\t",arr[i] );
		}
		
		fclose(fpointer);
	}
//7.To load the array from a file
	else if(choice ==7)
	{
		FILE *fpointer;
		fpointer =fopen("arraylist.txt","r");
		
		
			for(int i=n;!feof(fpointer);i++)
			{
			n=n+1;
			fscanf(fpointer,"%d",&arr[n]);
			}
		
	}
//8.exit
    else if(choice==8)
	{
		exit(0);
	}
   else
	{
		printf("Invalid Option. Please try again  \n ");
	}
}
}
	

