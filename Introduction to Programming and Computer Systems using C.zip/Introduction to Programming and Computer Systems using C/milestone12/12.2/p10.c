#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include"ownlibrary.h"
int main()
{
	
	int choice,i=0;
	while(1)
	{
	char* word=(char*)malloc(sizeof(char*));
	char* meaning=(char*)malloc(sizeof(char*));
	char* search=(char*)malloc(sizeof(char*));
	char* remove=(char*)malloc(sizeof(char*));
	printf("1.add word to library \n 2.search word \n 3.remove word from dictionary \n 4.print link list \n 5.save to text file \n 6.load to array \n 7.exit \n");
	printf("enter choice ");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:
		printf("enter a word :");
		scanf("%s",word);
		printf("enter meaning :");
		scanf("%s",meaning);
		BuildOneTwoThree(head,word,meaning);
		
		print1(head);
		i++;
		break;
	case 2:
		printf("enter a word for search:");
		scanf("%s",search);
		wordsearch(head,search);
		print1(head);
		break;
	case 3:
		printf("enter a word for remove:");
		scanf("%s",remove);
		deleteword(&head,remove);
		printdict(&head);
		break;
	case 4:
		print1(head);
		break;
	
	case 5:
		intofile(head);
		break;
	case 6:
		intoarray(head);
		printdict(&head);
		break;
	case 7:
		return 0;
		break;
	default:
		printf("wrong choice ");
		break;

	
		
	}
	
	}
}