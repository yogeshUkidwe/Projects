#include<stdlib.h>
#include<stdio.h>
#include"ownlibrary.h"
struct node
{
	char* word ;
	char* meaning;
	struct node* next;
};
char BuildOneTwoThree(struct node* y,char* word1,char* meaning1)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->word=word1;
	temp->meaning=meaning1;
	temp->next=head;
	head=temp;
	
	return 0;
}
void print1(struct node* printt)
{
	int i=1;
	printf("\n list is :\n");
	for (; printt != NULL; printt=printt->next)
	{
		printf("%s =",printt->word);
		printf("%s \n",printt->meaning);
		i++;
	}
}

void printdict(struct node** printt)
{
  struct node *temp=*printt;
	printf("\n list is :\n");
	for (; temp != NULL; temp=temp->next)
	{
		printf("word=%s\n",temp->word);
		printf("meaning=%s\n",temp->meaning);
	}
}

int length(char *str)
{ 
	int i;
	for( i = 0; str[i] != '\0'; i++)
	{
		
	}
	return (i);
	return 0;
	
}
int str_compare1(char *str1, char *str2)
{
	int flag=0,mlag=0,lag=0,n=0;
	int len =length(str1);
	int len1=length(str2);
	if(len>len1)
	{
		return 1;
	}
	else if(len<len1)
	{
		return 2;
	}
	else if (len==len1)
	{
		len =n;
	}
		
	for( int i = 0; i<=n; i++)
	{
		if(str1[i]>str2[i])
		{
			flag++;
		}
		else if(str1[i]<str2[i])
		{
			mlag++;
		}
		else 
		{
			lag++;
		}
	}
	if (lag>flag && lag>mlag)
	{
		return 3;
	}
	else if (flag>mlag)
	{
		return 1;
	}
	else if(flag<mlag)
	{
		return 2;
	}
	else
	{
	if(str1==NULL || str2==NULL )
	{
		printf("-1 error found \n");
	}
	return 9;
	}
	return 0;
}
char wordsearch(struct node* head, char* search ) 
{
	struct node* current = head;
	int count = 0; 
	for (current = head; current != NULL; current = current->next)
	{
		count=str_compare1(current->word, search);
		if (count == 3) 
		{
			printf("meaning of %s is ",current->word);
			printf("%s",current->meaning);
			return 4;
		}
		
	}
	return  count;
}
void deleteword(struct node** headr,char* remove) 
{
	struct node* current = *headr; 
	struct node* nextNext ;
	struct node* temp=*headr ;
	struct node* temp2;
	int count=0;
	int pos=0,flag=0,i=0;
	while (current != NULL ) 
	{
		count=str_compare1(current->word,remove);
			
		if(count==3)
		{
		printf("op");
		flag=1;
		break;
		}
		else 
		{
		pos++;
		current=current->next;
		printf("not found");
		}
	}
	if(flag==1&&pos==0)
	{
		*headr=temp->next;
		
		free(temp);
		return ;
	}
	else if(flag==1)
	{
		for(i=0;i<pos-1;i++)
		{
		temp=temp->next;
		}
		nextNext = temp->next;
		temp2=nextNext->next;
		free(nextNext);
		temp->next = temp2;
	}
	
}
int intofile(struct node* head)
{
	FILE *fpointer= NULL;
		fpointer =fopen("arraylinklist.txt","w");
		for (; head != NULL;  head=head->next)
		{
		fprintf(fpointer,"%s:",head->word );
		fprintf(fpointer,head->meaning);
		fprintf(fpointer,"\n");
		}
		
		fclose(fpointer);
		return 0;
}
char** str_tokenize(char *str, char c)
{
	int i=0,flag=0,count=1,j=0;
	char* word_dup=(char*)malloc(100*sizeof(char));
	char* meaning_dup=(char*)malloc(100*sizeof(char));
	for( i = 0; str[i]!= '\0'; i++)
	{
		count++;
		if(str[i]==c)
		{
			flag=1;	
		}
		if(flag==1)
		{
	       word_dup[i]='\0';
			meaning_dup[j]=str[i+1];
			j++;	
		}
		else
		{
			word_dup[i]=str[i];
		}
		
	}
	meaning_dup[j]='\0';
	
	BuildOneTwoThree(head,word_dup,meaning_dup);
		
		
return 0;
}
int intoarray(struct node* head)
{
	FILE *fpointer;
	int count=0;
	fpointer =fopen("arraylinklist.txt","r");
	char ok[100];
	while(!feof(fpointer))
	{
	
		fscanf(fpointer,"%s",ok);
		str_tokenize(ok,':');
		count++;
	}
	if(count==1)
	{
	printf("file is empty");
	}
	fclose(fpointer);
	return 0;
}

	
