char wordsearch1(struct node* head, char** tweet ) 
{

	struct node* current = head;
	int count=0, i=0,size=0; 
	printf("2");
	char* dup=(char*)malloc(100*sizeof(char));
	*(tweet+(size++)) = (char*)malloc((11 )* sizeof(char));
	*(tweet+(size)) = (char*)realloc(*(tweet+size),(11)* sizeof(char));
	printf("3");
		while ((tweet+i) != '\0') 
		{
	printf("4");
                if (**(tweet+i) == ' ')
				{
					
                        dup = '\0';
                        printf("%s ",dup);
				}
				else 
				{
                        dup = *(tweet+i);
				}
                i++;
        
				for (current = head; current != NULL; current = current->next)
				{
					count=str_compare1(current->word,dup);
					if (count == 3) 
					{
						printf("\n %s \n",dup);
						*(tweet+i)=(current->meaning);
					}
				
						printf("ps %s ",*tweet);
						
						return 4;
				}
		}
	return  count;
}

	
