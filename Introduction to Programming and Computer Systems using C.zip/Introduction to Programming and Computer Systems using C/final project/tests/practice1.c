char wordsearch1(struct node* head, char** tweet ) 
{

	struct node* current = head;
	int count = 0,i=0,j=0,k=0; 
	char dup[100];
	char dup_word[100];
	while(*((*tweet)+i)!='\0')
	{
			printf("2");
			while(*((*tweet)+i)!=' ') 
			{
				printf("3");
				printf("%c",*((*tweet)+i));
				*(dup+j) =*((*tweet)+i);
				*(dup_word+k)=*((*tweet)+i);
				i++;
				j++;
				k++;
			}
			dup_word[j] = '\0';
			dup[j] = '\0';
			k=0;
			printf("4");
			printf("dup_world=%s \n",dup_word);
			for (current = head; current != NULL; current = current->next)
			{
				count=str_compare1(current->word,dup_word);
				if (count == 3) 
				{
					printf("dup find=%s \n",dup_word);
					mem_copy(dup+i,current->meaning,k);
					
				}
				//printf("\n tweet=%s",*(tweet+k));k++;
			printf("dup=%s ",dup);
			}
			printf("ff");
	 i++;
	}
	return  count;
}
