char wordsearch1(struct node* head, char* tweet ) 
{

	struct node* current = head;
	int i=0,j=0,len=0,k=0,count=0,size=0; 
	char* dup=(char*)malloc(100*sizeof(char));
	char** dup1=NULL;
	dup1=(char**)malloc(1*sizeof(char*));
	while (tweet[i] != '\0') 
	{
        if (tweet[i] == ' ') 
		{
            dup[j] = '\0';
			len=length(dup);
			*(dup1+size) = (char*)malloc((len+1 )* sizeof(char));
			mem_copy(*(dup1+size),dup,len);
			size++;
			j = 0;
		}
		else
		{
            dup[j++] = tweet[i];
		}
        i++;
	}
	dup[j] = '\0';
	len=length(dup);
	*(dup1+size) = (char*)malloc((len+1 )* sizeof(char));
	mem_copy(*(dup1+size),dup,len);
	for(k=0;k<=size;k++)
	{
		for (current = head; current != NULL; current = current->next)
		{
			count=str_compare1(current->word,*(dup1+k));
			if (count == 3) 
			{
				*(dup1+k)= current->meaning;
				printf("dup find=%s \n",*(dup1+k));
				
			}
		}
	}
	for(k=0;k<=size;k++)
	{
		printf("%s ",*(dup1+k));
	}		
	return 0;
	
}
