#ifndef ownlink
#define ownlink
struct node* head;
void clear(void);
char BuildOneTwoThree(struct node* y,char* word,char* meaning);
void print1(struct node* printt);
int length(char *str);
int intofile(struct node* head);
char** str_tokenize(char *str, char c);
int intoarray(struct node* head);
char wordsearch1(struct node* head, char* search ) ;
void *mem_copy(void *dest, const void *src, unsigned int n);
char wordsearch1(struct node* head, char* tweet ) ;
void printdict(struct node** printt);
char wordsearch(struct node* head, char* search ) ;
int str_compare1(char *str1, char *str2);
void deleteword(struct node** headr,char* remove) ;
int str_add(char **str1, char *str2,int size);
int str_find_substring1(char *str1, char *str2);
#endif