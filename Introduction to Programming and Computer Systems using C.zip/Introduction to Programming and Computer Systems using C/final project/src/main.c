#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<conio.h>
#include"ownlibrary.h"
int main(int argc, char * argv[])
{

	while(1)
	{
	char* word=(char*)malloc(140*sizeof(char*));
	char* tweet=(char*)malloc(140*sizeof(char*));
	char* meaning=(char*)malloc(140*sizeof(char*));   
	int choice,i=0,count=0;
	printf("\n1.Convert a string to tweet \n2.Add new word to dictionary \n3.Save the current dictionary to a file \n4.Batch load a new dictionary items from a file \n5.Exit \n");
	printf("enter choice ");
	if(scanf("%d",&choice)!=1)
	{
		printf("please enter 1 to 5 number ");
		break;
	}
	switch(choice)
	{
	case 1:
		printf("enter a tweet");
		scanf(" %[^\n]s",tweet);
		if(head==NULL)
		{
			FILE *fpointer = fopen(argv[1], "r");
			if(argv[1]==NULL)
			{
				printf("not attached file ");
				break;
			}
			printf("default file is uploaded\n");
			char ok[100];
			while(!feof(fpointer))
			{
				fgets(ok,100,fpointer);
				str_tokenize(ok,':');
				count++;
			}
			if(count==1)
			{
				printf("file is empty");
			}
			fclose(fpointer);
		}
		wordsearch1(head,tweet);
		
		break;
	case 2:
		printf("enter a word :");
		scanf(" %[^\n]s",word);
		printf("enter meaning :");
		scanf("%s",meaning);
		BuildOneTwoThree(head,word,meaning);
		
		print1(head);
		i++;
		break;
	
	
	case 3:
		intofile(head);
		break;
	case 4:
		intoarray(head);
		printdict(&head);
		break;
	
	case 5:
		return 0;
		break;
	default:
		printf("wrong choice ");
		break;

	
		
	}
	
	}
}