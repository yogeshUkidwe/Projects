#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"ownlibrary.h"
struct node
{
	char* word ;
	char* meaning;
	struct node* next;
};
void clear(void)
{
		char ch;
		while((ch=getchar())!='\n' && ch != EOF);
}
char BuildOneTwoThree(struct node* y,char* word1,char* meaning1)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->word=word1;
	temp->meaning=meaning1;
	temp->next=head;
	head=temp;
	
	return 0;
}
void print1(struct node* printt)
{
	int i=1;
	printf("\n list is :\n");
	for (; printt != NULL; printt=printt->next)
	{
		printf("%s =",printt->word);
		printf("%s \n",printt->meaning);
		i++;
	}
}

void printdict(struct node** printt)
{
  struct node *temp=*printt;
	printf("\n list is :\n");
	for (; temp != NULL; temp=temp->next)
	{
		printf("word=%s\n",temp->word);
		printf("meaning=%s\n",temp->meaning);
	}
}

int length(char *str)
{ 
	int i;
	for( i = 0; str[i] != '\0'; i++)
	{
		
	}
	return (i);
	return 0;
	
}
int str_compare1(char *str1, char *str2)
{
	int flag=0,mlag=0,lag=0,n=0;
	int len =length(str1);
	int len1=length(str2);
	if(len>len1)
	{
		return 1;
	}
	else if(len<len1)
	{
		return 2;
	}
	else if (len==len1)
	{
		len =n;
	}
		
	for( int i = 0; i<=n; i++)
	{
		if(str1[i]>str2[i])
		{
			flag++;
		}
		else if(str1[i]<str2[i])
		{
			mlag++;
		}
		else 
		{
			lag++;
		}
	}
	if (lag>flag && lag>mlag)
	{
		return 3;
	}
	else if (flag>mlag)
	{
		return 1;
	}
	else if(flag<mlag)
	{
		return 2;
	}
	else
	{
	if(str1==NULL || str2==NULL )
	{
		printf("-1 error found \n");
	}
	return 9;
	}
	return 0;
}
void deleteword(struct node** headr,char* remove) 
{
	struct node* current = *headr; 
	struct node* nextNext ;
	struct node* temp=*headr ;
	struct node* temp2;
	int count=0;
	int pos=0,flag=0,i=0;
	while (current != NULL ) 
	{
		count=str_compare1(current->word,remove);
			
		if(count==3)
		{
		printf("op");
		flag=1;
		break;
		}
		else 
		{
		pos++;
		current=current->next;
		printf("not found");
		}
	}
	if(flag==1&&pos==0)
	{
		*headr=temp->next;
		
		free(temp);
		return ;
	}
	else if(flag==1)
	{
		for(i=0;i<pos-1;i++)
		{
		temp=temp->next;
		}
		nextNext = temp->next;
		temp2=nextNext->next;
		free(nextNext);
		temp->next = temp2;
	}
	
}
int intofile(struct node* head)
{
	FILE *fpointer= NULL;
		fpointer =fopen("arraylinklist.txt","w");
		for (; head != NULL;  head=head->next)
		{
		fprintf(fpointer,"%s:",head->word );
		fprintf(fpointer,head->meaning);
		fprintf(fpointer,"\n");
		}
		
		fclose(fpointer);
		return 0;
}
char** str_tokenize(char *str, char c)
{
	int i=0,flag=0,count=1,j=0;
	char* word_dup=(char*)malloc(100*sizeof(char));
	char* meaning_dup=(char*)malloc(100*sizeof(char));
	for( i = 0; str[i]!= '\0'; i++)
	{
		count++;
		if(str[i]==c)
		{
			flag=1;	
		}
		if(flag==1)
		{
	       word_dup[i]='\0';
			meaning_dup[j]=str[i+1];
			j++;	
		}
		else
		{
			word_dup[i]=str[i];
		}
	}
	meaning_dup[j]='\0';
	
	BuildOneTwoThree(head,word_dup,meaning_dup);
		
		
return 0;
}
int intoarray(struct node* head)
{
	FILE *fpointer;
	int count=0;
	fpointer =fopen("arraylinklist.txt","r");
	char ok[100];
	while(!feof(fpointer))
	{
	
		fgets(ok,100,fpointer);
		str_tokenize(ok,':');
		count++;
	}
	if(count==1)
	{
	printf("file is empty");
	}
	fclose(fpointer);
	return 0;
}
void *mem_copy(void *dest, const void *src, unsigned int n)
{
int i=0;
char *src1=(char *)src;
char *dest1=(char *)dest;
		if(NULL == src) 
		{
				return NULL;
				 
		} 
  
         for(i=0;i<n;i++)
			{  
				dest1[i]=src1[i];
			}
			dest1[i]='\0';
	return dest1; 
	return 0;
} 
int str_find_substring1(char *str1, char *str2)
{
	int flag,i;
	int n1=length(str1);
	int n2=length(str2);
	if(str1==NULL || str2==NULL)
	{
		printf("-1 error found \n");
	}
	for ( i = 0; i <= n1 - n2; i++)
    {
        for (int j = i; j < i + n2; j++)
        {
            flag = 1;
            if (str1[j] != str2[j - i])
            {
                flag = 0;
				
                break;
            }
        }
        if (flag == 1)
            break;
    }
	if (flag == 1)
	{
   
		return i;
	}
    else
	{
	   return -1;
	}
	return 0;
	
}

char wordsearch1(struct node* head, char* tweet ) 
{

	struct node* current = head;
	int k=0,l=0,count=0,i=0; 
	char* dup=(char*)malloc(140*sizeof(char));
	k=length(tweet);
	mem_copy(dup,tweet,k);
	
		for (current = head; current != NULL; current = current->next)
		{
			for(int m=0;m<=k;m++)
			{
				l=str_find_substring1(dup,current->word);
				if(l!=-1)
				{
					count=length(current->word)+count+1;
					mem_copy(dup+l,current->meaning,k);
					
					mem_copy(dup+l+length(current->meaning),tweet+count+l,length(tweet+l));				
								
				}
			}
		}
		while(1)
		{
		if(dup[i]=='\0')
		{
			break;
		}
		if(dup[i]=='\n')
		{
				dup[i]=' ';
		
		}
		i++;
		}
	printf("%s",dup);
	return 0;
	
}



	
