#include<stdlib.h>
#include<stdio.h>
char** str_tokenize(char *str, char c);
int main()
{
	FILE *fpointer;
	fpointer =fopen("f3.txt","r");
	char ok[100];
	while(!feof(fpointer))
	{
		fgets(ok,100,fpointer);
		
		str_tokenize(ok,':');
		
	}
	fclose(fpointer);
}
char** str_tokenize(char *str, char c)
{
	int last;
	printf("word=");
	for( int i = 0; str[i] != '\0'; i++)
	{
		
		if(str[i]==c)
		{
			
			printf("\n");
			printf("meaning=");
			str[i]='\0';
			
		}
		else 
		{
		str[i]=str[i];
		
		}
		
		printf("%c",str[i]);
		last=i;
	}
	printf("\n%c\n",str[last+1]);		
		
return 0;
}
